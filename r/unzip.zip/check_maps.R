#set working directory
if(!'rstudioapi' %in% installed.packages())install.packages('rstudioapi')
wd<-dirname(dirname(rstudioapi::getSourceEditorContext()$path)) #now it automatically finds the parent folder to folder where this script is saved
setwd(wd)

#load packages
require('terra')
require('sf')

#set graphical parameters
par(mfrow=c(2,3))

#define object
shpdir<-"data\\ymaps17\\wheat17\\2_epsg3006"

#list yield shape.files
ff<-list.files(shpdir)
sel1<-grepl(x=ff, pattern=".shp")
sel2<-grepl(x=ff, pattern=".shp.")
sel3<-grepl(x=ff, pattern="block_sub4.shp")
sel4<-grepl(x=ff, pattern="block_sub")
blockname<-ff[!sel2&sel3]
ff<-ff[sel1&!sel2&!sel3&!sel4]

#import blockdata
b <-vect(file.path(shpdir,blockname))
summary(b)
#plot(b)

#buffer blockdata
bsmall<-buffer(x=b, width=-30)
#plot(bsmall, add=T)
#(sum(expanse(b))-sum(expanse(bsmall)))/sum(expanse(b))

#import yield shape files
#create output directory if it does not exists
#dname<-file.path(shpdir,'epsg3006')
#if(!dir.exists(dname))dir.create(dname)
for(i in ff){
  s <- vect(file.path(shpdir,i))
  a<-as.data.frame(s)
  sel<-complete.cases(a); s<-s[sel,]
  summary(s)
  
  #compute turn (change in heading since previous point)
  a<-s$Heading
  p<-10
  id<-(p+1):(nrow(s)-p)
  for(j in -p:p){ifelse(j==-p, yes= aa<-a[id+j], no=aa<-cbind(aa,a[id+j]))}
  turn<-apply(aa, 1, var)
  pad<-rep(NA, p); turn<-c(pad, turn, pad)
  s$turn<-turn
  sel<-!is.na(s$turn); s<-s[sel,]
  summary(s)
  
  #compute no of neighbouring points
  a<-as.data.frame(crds(s))
  a<-FNN::knn.dist(data=a, k=100, algorithm='brute')
  head(a)
  a<-a<5
  s$density<-rowSums(a)

  
  #merge all point datasets to one
  s$fname<-i
  if(i == ff[1]) {sall<-s} else {sall<-rbind(sall, s)}
  #plot(sall, " WetMass", col=rainbow(25), cex=0.2 , main =i)
  
  #reproject and export
  #s<-project(s, "EPSG:3006")
  #fname<-file.path(dname, i)
  #writeVector(x=s, filename=fname, overwrite=TRUE)

  #remove points with extreme yield, moisture or distance
  n<-'turn'; a<-as.data.frame(s)[,n]; sel1<-a<=5; plot(b[s,],main =i, xlab=n); plot(s[!sel1,],add=T)
  n<-'Moisture'; a<-as.data.frame(s)[,n]; sel2<-a>=15 & a <=23; plot(b[s,],main =i, xlab=n); plot(s[!sel2,],add=T)
  n<-'WetMass'; a<-as.data.frame(s)[,n]; sel3<-a>=3000&a<=13000; plot(b[s,],main =i, xlab=n); plot(s[!sel3,],add=T)
  n<-'DISTANCE'; a<-as.data.frame(s)[,n]; sel4<-a>=0.5; plot(b[s,],main =i, xlab=n); plot(s[!sel4,],add=T)
  #n<-'SWATHWIDTH'; a<-as.data.frame(s)[,n]; sel5<-a>=8.5; plot(b[s,],main =i, xlab=n); if(sum(!sel5)>0) plot(s[!sel5,],add=T)
  n<-'density'; a<-as.data.frame(s)[,n]; sel5<-a<=12; plot(b[s,],main =i, xlab=n); if(sum(!sel5)>0) plot(s[!sel5,],add=T)
  sel<-sel1&sel2&sel3&sel4&sel5
  s<-s[sel,]
  #crop point data by polygons
  #s<-crop(x=s, y=bsmall)

  plot(b[s,],main =i)
  plot(s, "WetMass", col=rainbow(25), cex=0.2 ,  add=T)
  plot(bsmall[s,], add=T)
}




